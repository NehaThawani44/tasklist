package com.finanzdata.taskservice.service;

import com.finanzdata.taskservice.domain.ToDo;
import com.finanzdata.taskservice.repository.ToDoRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

@Service
public class ToDoService {
    private static final Logger logger = LoggerFactory.getLogger(ToDoService.class);

    private final ToDoRepository toDoRepository;

    @Autowired
    public ToDoService(ToDoRepository toDoRepository) {
        this.toDoRepository = toDoRepository;
    }

    public List<ToDo> findAllToDos() {
        logger.info("Retrieving all todos");
        return toDoRepository.findAll();
    }

    public ToDo saveTodo(ToDo toDo) {
        logger.info("Saving a ToDo");
        return toDoRepository.save(toDo);
    }

    public Optional<ToDo> findTodoById(Long id) {
        logger.info("Finding ToDo by ID: {}", id);
        return toDoRepository.findById(id);
    }

    public void deleteToDoById(Long id) {
        logger.info("Deleting ToDo by ID: {}", id);
        toDoRepository.deleteById(id);
    }

    public List<ToDo> getTodosByStatus(String status) {
        logger.info("Retrieving ToDos by status: {}", status);
        return toDoRepository.findByStatus(status);
    }

    public List<ToDo> getTodosCompletionDateBefore(LocalDate date) {
        logger.info("Retrieving ToDos with completion date before: {}", date);
        return toDoRepository.findAllWithCompletionDateBefore(date);
    }
}
