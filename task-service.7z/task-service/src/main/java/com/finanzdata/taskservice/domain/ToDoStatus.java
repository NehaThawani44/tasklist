package com.finanzdata.taskservice.domain;

public enum ToDoStatus {
    COMPLETED,PENDING
}
