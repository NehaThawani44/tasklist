package com.finanzdata.taskservice.controller;



import com.finanzdata.taskservice.domain.ToDo;
import com.finanzdata.taskservice.repository.ToDoRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

import java.net.URI;
import java.util.List;
import java.util.NoSuchElementException;
import java.util.Optional;

@RestController
@RequestMapping("/todos")
public class ToDoController {
    private static final Logger logger = LoggerFactory.getLogger(ToDoController.class);

    @Autowired
    private ToDoRepository toDoRepository;

    @GetMapping
    public ResponseEntity<List<ToDo>> getAllTodos() {
        List<ToDo> toDos = toDoRepository.findAll();
        logger.info("Fetching all todos");
        if (toDos.isEmpty()) {
            return ResponseEntity.noContent().build();
        }
        return ResponseEntity.ok(toDos);
    }

    @GetMapping("/{id}")
    public ResponseEntity<ToDo> getTodoById(@PathVariable Long id) {
        logger.info("Fetching ToDo by id: {}", id);
        return toDoRepository.findById(id)
                .map(ResponseEntity::ok)
                .orElseThrow(() -> new NoSuchElementException("ToDo not found with id " + id));
    }

    @PostMapping("/")
    public ResponseEntity<ToDo> createTodo(@RequestBody ToDo toDo) {
        logger.info("Creating new ToDo");
        ToDo savedTodo = toDoRepository.save(toDo);
        URI location = ServletUriComponentsBuilder.fromCurrentRequest()
                .path("/{id}")
                .buildAndExpand(savedTodo.getId())
                .toUri();
        return ResponseEntity.created(location).body(savedTodo);
    }

    @PutMapping("/{id}")
    public ResponseEntity<ToDo> updateTodo(@PathVariable Long id, @RequestBody ToDo toDo) {
        logger.info("Updating ToDo with id: {}", id);
        return toDoRepository.findById(id)
                .map(existingTodo -> {
                    existingTodo.setTitle(toDo.getTitle());
                    existingTodo.setDescription(toDo.getDescription());
                    existingTodo.setCompletionDate(toDo.getCompletionDate());

                    toDoRepository.save(existingTodo);
                    return ResponseEntity.ok(existingTodo);
                })
                .orElseThrow(() -> new NoSuchElementException("ToDo not found with id " + id));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteToDo(@PathVariable Long id) {
        logger.info("Deleting ToDo with id: {}", id);
        return toDoRepository.findById(id)
                .map(toDo -> {
                    toDoRepository.delete(toDo);
                    return ResponseEntity.noContent().<Void>build();
                })
                .orElseThrow(() -> new NoSuchElementException("ToDo not found with id " + id));
    }
}
