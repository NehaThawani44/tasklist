#!/bin/bash

# Stop script on any error
set -e

# Check if running in CI environment
if [ "$CI" == "true" ]; then
    echo "Running in CI environment..."
fi

# Clean and build the project
mvn clean install

# Optionally, deploy based on profile
case "$1" in
  "dev")
    mvn spring-boot:run -Dspring-boot.run.profiles=dev
    ;;
  "prod")
    java -jar target/task-service-0.0.1-SNAPSHOT.jar --spring.profiles.active=prod
    ;;
  *)
    echo "Usage: $0 {dev|prod}"
    exit 1
    ;;
esac