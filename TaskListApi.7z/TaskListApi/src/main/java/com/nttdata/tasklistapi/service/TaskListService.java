package com.nttdata.tasklistapi.service;


import io.camunda.tasklist.CamundaTaskListClient;
import io.camunda.tasklist.auth.SimpleAuthentication;
import io.camunda.tasklist.dto.TaskSearch;
import io.camunda.tasklist.exception.TaskListException;
import org.springframework.stereotype.Service;

@Service
public class TaskListService {
    CamundaTaskListClient client;
    public TaskListService() throws TaskListException {

        SimpleAuthentication sa = new SimpleAuthentication("demo", "demo");

//shouldReturnVariables will change the default behaviour for the client to query variables along with tasks.
        client = new CamundaTaskListClient.Builder().taskListUrl("http://localhost:8082").shouldReturnVariables().authentication(sa).build();



    }

    public void findTasks(String group) throws TaskListException {
        client.getTasks(new TaskSearch().setGroup(group));
    }

}
