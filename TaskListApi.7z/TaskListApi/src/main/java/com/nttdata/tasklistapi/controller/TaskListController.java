package com.nttdata.tasklistapi.controller;


import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import io.camunda.tasklist.dto.Task;
import org.apache.catalina.connector.Response;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.apache.tomcat.util.json.ParseException;

import java.io.IOException;
import java.net.URI;
import java.net.URISyntaxException;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.util.List;
import java.util.Map;

@RestController
public class TaskListController {

    @GetMapping("/tasks")
    public List<Task> findTasks(String group){
        //call tasklist API to fetch tasks
        return null;
    }

    @GetMapping("/usertasks")
    public ResponseEntity  findTasksForUser(String userId){
     Task t = new Task();
     t.setCandidateUsers(List.of("Neha", "CHandra"));
        return ResponseEntity.ok(t.getCandidateUsers());

    }

    @PostMapping("tasks/search")
    public void findTasks(@RequestBody String accessToken, Map<String, Object> parameters)
            throws URISyntaxException, IOException, InterruptedException, ParseException {
        // get the access token
        HttpClient client = HttpClient.newHttpClient();
        var request = HttpRequest.newBuilder(new URI("http://localhost:8082/v1/tasks/search"))
                .header("Content-Type", "application/json")
                .header("Accept", "application/json")
                .header("Authorization", "Bearer " + accessToken)
                .POST(HttpRequest.BodyPublishers.ofString(new ObjectMapper().writeValueAsString(parameters))).build();

        HttpResponse<String> response = client.send(request, HttpResponse.BodyHandlers.ofString());
        var mapper = new ObjectMapper();
        mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
        System.out.println(response.body());


    }

}
